import React, { useState } from 'react';
import { Search, ShoppingCart, Menu, Star, MapPin, ChevronDown, Filter } from 'lucide-react';

type Part = {
  id: number;
  name: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  category: string;
  inStock: boolean;
};

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState('Алматы');
  const [selectedCategory, setSelectedCategory] = useState('Все');

  const parts: Part[] = [
    {
      id: 1,
      name: 'Масляный фильтр Great Wall Hover H5',
      brand: 'Great Wall',
      price: 1200,
      oldPrice: 1500,
      rating: 4.8,
      reviews: 245,
      image: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=500&auto=format',
      category: 'Фильтры',
      inStock: true
    },
    {
      id: 2,
      name: 'Тормозные колодки передние Geely Atlas',
      brand: 'Geely',
      price: 12500,
      oldPrice: 15000,
      rating: 4.9,
      reviews: 187,
      image: 'https://images.unsplash.com/photo-1600706432502-77a0e2e32771?w=500&auto=format',
      category: 'Тормозная система',
      inStock: true
    },
    {
      id: 3,
      name: 'Воздушный фильтр Haval F7',
      brand: 'Haval',
      price: 3200,
      rating: 4.7,
      reviews: 156,
      image: 'https://images.unsplash.com/photo-1635773054018-1d68618f979c?w=500&auto=format',
      category: 'Фильтры',
      inStock: true
    },
    {
      id: 4,
      name: 'Амортизатор передний Chery Tiggo 7 Pro',
      brand: 'Chery',
      price: 28500,
      oldPrice: 32000,
      rating: 4.6,
      reviews: 89,
      image: 'https://images.unsplash.com/photo-1582639510494-c80b5de9f148?w=500&auto=format',
      category: 'Подвеска',
      inStock: false
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-red-600 text-white">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Menu className="h-6 w-6 cursor-pointer" />
              <h1 className="text-xl font-bold">АвтоЗапчасти</h1>
            </div>
            
            <div className="flex-1 max-w-xl mx-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Поиск запчастей..."
                  className="w-full px-4 py-2 rounded-lg text-gray-900 focus:outline-none"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>

            <div className="flex items-center space-x-6">
              <div className="flex items-center cursor-pointer">
                <MapPin className="h-5 w-5" />
                <span className="ml-1">{selectedCity}</span>
                <ChevronDown className="h-4 w-4 ml-1" />
              </div>
              <ShoppingCart className="h-6 w-6 cursor-pointer" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-gray-500" />
            <div className="flex space-x-2">
              <button
                className={`px-4 py-2 rounded-full ${
                  selectedCategory === 'Все'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                onClick={() => setSelectedCategory('Все')}
              >
                Все
              </button>
              <button
                className={`px-4 py-2 rounded-full ${
                  selectedCategory === 'Фильтры'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                onClick={() => setSelectedCategory('Фильтры')}
              >
                Фильтры
              </button>
              <button
                className={`px-4 py-2 rounded-full ${
                  selectedCategory === 'Тормозная система'
                    ? 'bg-red-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                onClick={() => setSelectedCategory('Тормозная система')}
              >
                Тормозная система
              </button>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {parts
            .filter(part => selectedCategory === 'Все' || part.category === selectedCategory)
            .map((part) => (
              <div key={part.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <div className="relative">
                  <img
                    src={part.image}
                    alt={part.name}
                    className="w-full h-48 object-cover"
                  />
                  {!part.inStock && (
                    <div className="absolute top-0 left-0 right-0 bottom-0 bg-white/80 flex items-center justify-center">
                      <span className="text-gray-500 font-medium">Нет в наличии</span>
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-center mb-2">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium ml-1">{part.rating}</span>
                    <span className="text-sm text-gray-500 ml-1">({part.reviews})</span>
                  </div>
                  <h3 className="text-sm font-medium mb-2 line-clamp-2">{part.name}</h3>
                  <p className="text-xs text-gray-500 mb-2">Бренд: {part.brand}</p>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-lg font-bold">{part.price.toLocaleString()} ₸</span>
                    {part.oldPrice && (
                      <span className="text-sm text-gray-400 line-through">
                        {part.oldPrice.toLocaleString()} ₸
                      </span>
                    )}
                  </div>
                  {part.inStock && (
                    <button
                      className="mt-3 w-full bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition-colors"
                    >
                      Купить
                    </button>
                  )}
                </div>
              </div>
            ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-lg font-semibold mb-4">О нас</h4>
              <p className="text-gray-400">
                Крупнейший магазин автозапчастей для китайских автомобилей с доставкой по всему Казахстану.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Контакты</h4>
              <p className="text-gray-400">Телефон: +7 (727) 123-45-67</p>
              <p className="text-gray-400">Email: info@autozapchasti.kz</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Режим работы</h4>
              <p className="text-gray-400">Пн-Пт: 9:00 - 20:00</p>
              <p className="text-gray-400">Сб-Вс: 10:00 - 18:00</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;